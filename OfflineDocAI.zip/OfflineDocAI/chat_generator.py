import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import re

class ChatGenerator:
    def __init__(self, model, tokenizer):
        """Initialize the chat generator with trained model and tokenizer."""
        self.model = model
        self.tokenizer = tokenizer
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        self.model.eval()
        
    def generate_reply(self, input_text, max_length=100, temperature=0.8, top_p=0.9, 
                      repetition_penalty=1.2, num_return_sequences=1):
        """Generate a reply based on input context."""
        
        # Prepare input
        if not input_text.strip().endswith("User A:"):
            if "User A:" not in input_text:
                input_text += " User A:"
        
        # Tokenize input
        input_ids = self.tokenizer.encode(
            input_text, 
            return_tensors='pt',
            truncation=True,
            max_length=400  # Leave room for generation
        ).to(self.device)
        
        # Generate response
        with torch.no_grad():
            output = self.model.generate(
                input_ids,
                max_length=input_ids.shape[1] + max_length,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
                num_return_sequences=num_return_sequences,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
                early_stopping=True
            )
        
        # Decode the generated text
        generated_text = self.tokenizer.decode(output[0], skip_special_tokens=True)
        
        # Extract only the generated reply (after "User A:")
        reply = self.extract_user_a_reply(generated_text, input_text)
        
        # Clean up the reply
        reply = self.clean_reply(reply)
        
        return reply
    
    def extract_user_a_reply(self, generated_text, original_input):
        """Extract User A's reply from the generated text."""
        # Find the last occurrence of "User A:" in the generated text
        user_a_pos = generated_text.rfind("User A:")
        
        if user_a_pos != -1:
            # Extract text after "User A:"
            reply = generated_text[user_a_pos + len("User A:"):].strip()
            
            # Remove any subsequent "User B:" parts
            user_b_pos = reply.find("User B:")
            if user_b_pos != -1:
                reply = reply[:user_b_pos].strip()
            
            return reply
        else:
            # If no "User A:" found, try to extract from the end of original input
            if original_input in generated_text:
                reply = generated_text[len(original_input):].strip()
                return reply
            else:
                return generated_text.strip()
    
    def clean_reply(self, reply):
        """Clean and format the generated reply."""
        # Remove excessive whitespace
        reply = re.sub(r'\s+', ' ', reply).strip()
        
        # Remove incomplete sentences at the end
        sentences = reply.split('.')
        if len(sentences) > 1 and len(sentences[-1].strip()) < 5:
            reply = '.'.join(sentences[:-1]) + '.'
        
        # Limit length to reasonable size
        words = reply.split()
        if len(words) > 50:
            reply = ' '.join(words[:50]) + '...'
        
        # Ensure the reply doesn't repeat the input
        if reply.startswith("User B:") or reply.startswith("User A:"):
            # Extract just the message part
            colon_pos = reply.find(":")
            if colon_pos != -1:
                reply = reply[colon_pos + 1:].strip()
        
        # Handle empty replies
        if not reply or len(reply.strip()) < 2:
            reply = "I understand."
        
        return reply
    
    def generate_multiple_replies(self, input_text, num_replies=3, **kwargs):
        """Generate multiple reply options."""
        replies = []
        
        for i in range(num_replies):
            # Vary temperature for diversity
            temp = kwargs.get('temperature', 0.8) + (i * 0.1)
            kwargs['temperature'] = min(temp, 1.5)
            
            reply = self.generate_reply(input_text, **kwargs)
            if reply not in replies:  # Avoid duplicates
                replies.append(reply)
        
        return replies
    
    def chat_conversation(self, messages, max_context_length=5):
        """Generate a reply considering conversation history."""
        # Format conversation history
        context_messages = []
        
        # Take the last few messages for context
        recent_messages = messages[-max_context_length:] if len(messages) > max_context_length else messages
        
        for msg in recent_messages:
            if msg['sender'] == 'User B':
                context_messages.append(f"User B: {msg['text']}")
            elif msg['sender'] == 'User A':
                context_messages.append(f"User A: {msg['text']}")
        
        # Add the prompt for User A's response
        context_messages.append("User A:")
        
        # Generate reply
        full_context = " ".join(context_messages)
        reply = self.generate_reply(full_context)
        
        return reply
    
    def set_generation_params(self, **kwargs):
        """Set default generation parameters."""
        self.default_params = kwargs
    
    def get_model_info(self):
        """Get information about the model."""
        return {
            'model_name': self.model.__class__.__name__,
            'tokenizer_name': self.tokenizer.__class__.__name__,
            'vocab_size': len(self.tokenizer),
            'device': str(self.device),
            'num_parameters': sum(p.numel() for p in self.model.parameters())
        }
