import pandas as pd
import numpy as np
import re
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from transformers import GPT2Tokenizer
import torch

class DataProcessor:
    def __init__(self):
        """Initialize the data processor with tokenizer and preprocessing tools."""
        try:
            nltk.download('punkt', quiet=True)
        except:
            pass
        
        self.tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        self.processed_data = []
        
    def clean_text(self, text):
        """Clean and normalize text data."""
        if pd.isna(text):
            return ""
        
        # Convert to string and strip
        text = str(text).strip()
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep punctuation
        text = re.sub(r'[^\w\s\.\!\?\,\;\:\-\'\"]', '', text)
        
        return text
    
    def create_conversation_pairs(self, userA_df, userB_df):
        """Create conversation pairs from user chat data."""
        conversation_pairs = []
        
        # Ensure both dataframes have the required columns
        if 'message' not in userA_df.columns or 'timestamp' not in userA_df.columns:
            # If columns don't exist, create them from available data
            if len(userA_df.columns) >= 2:
                userA_df.columns = ['timestamp', 'message'] + list(userA_df.columns[2:])
            else:
                userA_df['timestamp'] = range(len(userA_df))
                userA_df['message'] = userA_df.iloc[:, 0] if len(userA_df.columns) > 0 else ""
        
        if 'message' not in userB_df.columns or 'timestamp' not in userB_df.columns:
            if len(userB_df.columns) >= 2:
                userB_df.columns = ['timestamp', 'message'] + list(userB_df.columns[2:])
            else:
                userB_df['timestamp'] = range(len(userB_df))
                userB_df['message'] = userB_df.iloc[:, 0] if len(userB_df.columns) > 0 else ""
        
        # Clean messages
        userA_df['message'] = userA_df['message'].apply(self.clean_text)
        userB_df['message'] = userB_df['message'].apply(self.clean_text)
        
        # Remove empty messages
        userA_df = userA_df[userA_df['message'].str.len() > 0]
        userB_df = userB_df[userB_df['message'].str.len() > 0]
        
        # Create conversation pairs
        # For simplicity, we'll pair messages sequentially
        min_length = min(len(userA_df), len(userB_df))
        
        for i in range(min_length - 1):
            # Use User B's message as context and User A's next message as target
            userB_msg = userB_df.iloc[i]['message']
            userA_response = userA_df.iloc[i]['message']
            
            if len(userB_msg) > 5 and len(userA_response) > 5:  # Filter very short messages
                conversation_pairs.append({
                    'userB_message': userB_msg,
                    'userA_response': userA_response,
                    'context_length': len(userB_msg.split())
                })
        
        return conversation_pairs
    
    def create_training_examples(self, conversation_pairs, context_window=3):
        """Create training examples with context."""
        training_examples = []
        
        for i, pair in enumerate(conversation_pairs):
            # Build context from previous conversations
            context_messages = []
            
            # Add previous conversation pairs as context
            start_idx = max(0, i - context_window)
            for j in range(start_idx, i):
                prev_pair = conversation_pairs[j]
                context_messages.append(f"User B: {prev_pair['userB_message']}")
                context_messages.append(f"User A: {prev_pair['userA_response']}")
            
            # Add current User B message
            context_messages.append(f"User B: {pair['userB_message']}")
            context_messages.append("User A:")
            
            # Create input text
            input_text = " ".join(context_messages)
            target_text = pair['userA_response']
            
            # Tokenize and check length
            input_tokens = self.tokenizer.encode(input_text, truncation=True, max_length=512)
            target_tokens = self.tokenizer.encode(target_text, truncation=True, max_length=128)
            
            if len(input_tokens) > 10 and len(target_tokens) > 3:  # Ensure minimum length
                training_examples.append({
                    'input_text': input_text,
                    'target_text': target_text,
                    'input_length': len(input_tokens),
                    'target_length': len(target_tokens)
                })
        
        return training_examples
    
    def load_and_process_data(self, userA_file, userB_file):
        """Load and process conversation data from CSV files."""
        try:
            # Load CSV files
            userA_df = pd.read_csv(userA_file)
            userB_df = pd.read_csv(userB_file)
            
            print(f"Loaded {len(userA_df)} User A messages and {len(userB_df)} User B messages")
            
            # Create conversation pairs
            conversation_pairs = self.create_conversation_pairs(userA_df, userB_df)
            print(f"Created {len(conversation_pairs)} conversation pairs")
            
            # Create training examples
            training_examples = self.create_training_examples(conversation_pairs)
            print(f"Generated {len(training_examples)} training examples")
            
            self.processed_data = training_examples
            
            return training_examples
            
        except Exception as e:
            print(f"Error processing data: {str(e)}")
            return []
    
    def get_tokenizer(self):
        """Return the tokenizer used for processing."""
        return self.tokenizer
    
    def prepare_batch(self, examples, max_length=512):
        """Prepare a batch of examples for training."""
        input_texts = [ex['input_text'] for ex in examples]
        target_texts = [ex['target_text'] for ex in examples]
        
        # Tokenize inputs
        input_encodings = self.tokenizer(
            input_texts,
            truncation=True,
            padding=True,
            max_length=max_length,
            return_tensors='pt'
        )
        
        # Tokenize targets
        target_encodings = self.tokenizer(
            target_texts,
            truncation=True,
            padding=True,
            max_length=128,
            return_tensors='pt'
        )
        
        return input_encodings, target_encodings
