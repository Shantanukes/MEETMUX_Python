import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import GPT2LMHeadModel, GPT2Tokenizer, AdamW, get_linear_schedule_with_warmup
import numpy as np
from tqdm import tqdm
import os

class ConversationDataset(Dataset):
    def __init__(self, examples, tokenizer, max_length=512):
        self.examples = examples
        self.tokenizer = tokenizer
        self.max_length = max_length
        
    def __len__(self):
        return len(self.examples)
    
    def __getitem__(self, idx):
        example = self.examples[idx]
        
        # Create input text with special format
        input_text = example['input_text'] + " " + example['target_text']
        
        # Tokenize
        encoding = self.tokenizer(
            input_text,
            truncation=True,
            max_length=self.max_length,
            padding='max_length',
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].squeeze()
        attention_mask = encoding['attention_mask'].squeeze()
        
        # Labels are the same as input_ids for language modeling
        labels = input_ids.clone()
        
        # Set padding tokens to -100 so they're ignored in loss calculation
        labels[attention_mask == 0] = -100
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': labels
        }

class ModelTrainer:
    def __init__(self, model_name='gpt2', learning_rate=2e-5, num_epochs=3, batch_size=4):
        """Initialize the model trainer."""
        self.model_name = model_name
        self.learning_rate = learning_rate
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        print(f"Using device: {self.device}")
        
        # Initialize model and tokenizer
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        self.model = GPT2LMHeadModel.from_pretrained(model_name)
        self.model.resize_token_embeddings(len(self.tokenizer))
        self.model.to(self.device)
        
    def train(self, training_examples, progress_callback=None):
        """Train the model on conversation data."""
        print(f"Starting training with {len(training_examples)} examples")
        
        # Create dataset and dataloader
        dataset = ConversationDataset(training_examples, self.tokenizer)
        dataloader = DataLoader(
            dataset, 
            batch_size=self.batch_size, 
            shuffle=True,
            num_workers=0  # Set to 0 for compatibility
        )
        
        # Setup optimizer and scheduler
        optimizer = AdamW(self.model.parameters(), lr=self.learning_rate)
        total_steps = len(dataloader) * self.num_epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=0,
            num_training_steps=total_steps
        )
        
        # Training loop
        self.model.train()
        total_loss = 0
        
        for epoch in range(self.num_epochs):
            epoch_loss = 0
            print(f"\nEpoch {epoch + 1}/{self.num_epochs}")
            
            for batch_idx, batch in enumerate(tqdm(dataloader, desc=f"Training Epoch {epoch + 1}")):
                # Move batch to device
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                # Forward pass
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                
                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()
                scheduler.step()
                
                epoch_loss += loss.item()
                total_loss += loss.item()
                
                # Print progress every 10 batches
                if batch_idx % 10 == 0:
                    print(f"Batch {batch_idx}, Loss: {loss.item():.4f}")
            
            avg_epoch_loss = epoch_loss / len(dataloader)
            print(f"Epoch {epoch + 1} completed. Average loss: {avg_epoch_loss:.4f}")
            
            # Call progress callback if provided
            if progress_callback:
                progress_callback(epoch, self.num_epochs)
        
        avg_total_loss = total_loss / (len(dataloader) * self.num_epochs)
        print(f"\nTraining completed! Average total loss: {avg_total_loss:.4f}")
        
        return self.model, self.tokenizer
    
    def save_model(self, save_path='./trained_model'):
        """Save the trained model and tokenizer."""
        os.makedirs(save_path, exist_ok=True)
        self.model.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        print(f"Model saved to {save_path}")
    
    def load_model(self, model_path='./trained_model'):
        """Load a trained model and tokenizer."""
        self.model = GPT2LMHeadModel.from_pretrained(model_path)
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model.to(self.device)
        print(f"Model loaded from {model_path}")
        
        return self.model, self.tokenizer
    
    def calculate_perplexity(self, examples):
        """Calculate perplexity on a set of examples."""
        self.model.eval()
        total_loss = 0
        total_tokens = 0
        
        with torch.no_grad():
            for example in examples:
                input_text = example['input_text'] + " " + example['target_text']
                
                encoding = self.tokenizer(
                    input_text,
                    return_tensors='pt',
                    truncation=True,
                    max_length=512
                )
                
                input_ids = encoding['input_ids'].to(self.device)
                
                outputs = self.model(input_ids, labels=input_ids)
                loss = outputs.loss
                
                total_loss += loss.item() * input_ids.size(1)
                total_tokens += input_ids.size(1)
        
        avg_loss = total_loss / total_tokens
        perplexity = torch.exp(torch.tensor(avg_loss))
        
        return perplexity.item()
