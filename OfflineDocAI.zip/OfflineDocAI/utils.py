import os
import json
import pickle
import torch
import numpy as np
import pandas as pd
from datetime import datetime
import logging
import re

def setup_logging(log_file='chat_system.log'):
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def save_json(data, filepath):
    """Save data to JSON file."""
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
        return True
    except Exception as e:
        print(f"Error saving JSON to {filepath}: {e}")
        return False

def load_json(filepath):
    """Load data from JSON file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading JSON from {filepath}: {e}")
        return None

def save_pickle(data, filepath):
    """Save data using pickle."""
    try:
        with open(filepath, 'wb') as f:
            pickle.dump(data, f)
        return True
    except Exception as e:
        print(f"Error saving pickle to {filepath}: {e}")
        return False

def load_pickle(filepath):
    """Load data using pickle."""
    try:
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    except Exception as e:
        print(f"Error loading pickle from {filepath}: {e}")
        return None

def clean_text(text):
    """Clean and normalize text."""
    if not isinstance(text, str):
        return ""
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text.strip())
    
    # Remove special characters but keep basic punctuation
    text = re.sub(r'[^\w\s\.\!\?\,\;\:\-\'\"]', '', text)
    
    return text

def calculate_text_stats(texts):
    """Calculate statistics for a list of texts."""
    if not texts:
        return {}
    
    word_counts = [len(text.split()) for text in texts]
    char_counts = [len(text) for text in texts]
    
    stats = {
        'total_texts': len(texts),
        'avg_words': np.mean(word_counts),
        'median_words': np.median(word_counts),
        'max_words': max(word_counts),
        'min_words': min(word_counts),
        'avg_chars': np.mean(char_counts),
        'total_words': sum(word_counts),
        'total_chars': sum(char_counts)
    }
    
    return stats

def format_conversation_for_display(messages, max_length=100):
    """Format conversation messages for display."""
    formatted = []
    
    for msg in messages:
        text = msg.get('text', '')
        sender = msg.get('sender', 'Unknown')
        timestamp = msg.get('timestamp', '')
        
        # Truncate long messages
        if len(text) > max_length:
            text = text[:max_length] + "..."
        
        formatted.append({
            'sender': sender,
            'text': text,
            'timestamp': timestamp,
            'display_text': f"{sender}: {text}"
        })
    
    return formatted

def create_conversation_context(messages, context_length=5):
    """Create context string from conversation messages."""
    if not messages:
        return ""
    
    # Take the last N messages
    recent_messages = messages[-context_length:] if len(messages) > context_length else messages
    
    context_parts = []
    for msg in recent_messages:
        sender = msg.get('sender', 'User')
        text = msg.get('text', '')
        context_parts.append(f"{sender}: {text}")
    
    return " ".join(context_parts)

def validate_csv_format(filepath, required_columns=None):
    """Validate CSV file format."""
    try:
        df = pd.read_csv(filepath)
        
        if required_columns:
            missing_cols = set(required_columns) - set(df.columns)
            if missing_cols:
                return False, f"Missing columns: {missing_cols}"
        
        if df.empty:
            return False, "CSV file is empty"
        
        return True, f"Valid CSV with {len(df)} rows and {len(df.columns)} columns"
        
    except Exception as e:
        return False, f"Error reading CSV: {e}"

def get_device_info():
    """Get information about available computing devices."""
    device_info = {
        'cuda_available': torch.cuda.is_available(),
        'cuda_device_count': torch.cuda.device_count() if torch.cuda.is_available() else 0,
        'current_device': 'cuda' if torch.cuda.is_available() else 'cpu'
    }
    
    if torch.cuda.is_available():
        device_info['cuda_device_name'] = torch.cuda.get_device_name(0)
        device_info['cuda_memory_allocated'] = torch.cuda.memory_allocated(0)
        device_info['cuda_memory_reserved'] = torch.cuda.memory_reserved(0)
    
    return device_info

def estimate_training_time(num_examples, batch_size, num_epochs, time_per_batch=2):
    """Estimate training time based on dataset size."""
    batches_per_epoch = (num_examples + batch_size - 1) // batch_size
    total_batches = batches_per_epoch * num_epochs
    estimated_seconds = total_batches * time_per_batch
    
    hours = estimated_seconds // 3600
    minutes = (estimated_seconds % 3600) // 60
    seconds = estimated_seconds % 60
    
    return {
        'total_seconds': estimated_seconds,
        'formatted_time': f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}",
        'batches_per_epoch': batches_per_epoch,
        'total_batches': total_batches
    }

def create_model_checkpoint(model, tokenizer, epoch, loss, save_dir='checkpoints'):
    """Create a model checkpoint."""
    os.makedirs(save_dir, exist_ok=True)
    
    checkpoint_name = f"checkpoint_epoch_{epoch}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    checkpoint_path = os.path.join(save_dir, checkpoint_name)
    
    checkpoint_data = {
        'model_state_dict': model.state_dict(),
        'epoch': epoch,
        'loss': loss,
        'timestamp': datetime.now().isoformat(),
        'model_name': model.__class__.__name__
    }
    
    torch.save(checkpoint_data, f"{checkpoint_path}.pt")
    tokenizer.save_pretrained(checkpoint_path)
    
    return checkpoint_path

def load_model_checkpoint(checkpoint_path, model, tokenizer):
    """Load a model checkpoint."""
    try:
        # Load model state
        checkpoint_data = torch.load(f"{checkpoint_path}.pt", map_location='cpu')
        model.load_state_dict(checkpoint_data['model_state_dict'])
        
        # Load tokenizer
        from transformers import GPT2Tokenizer
        tokenizer = GPT2Tokenizer.from_pretrained(checkpoint_path)
        
        return model, tokenizer, checkpoint_data
        
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        return None, None, None

def generate_training_report(training_history, model_info, dataset_info):
    """Generate a comprehensive training report."""
    report = f"""
Training Report
===============
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Model Information:
- Model Type: {model_info.get('model_name', 'Unknown')}
- Total Parameters: {model_info.get('num_parameters', 'Unknown'):,}
- Device: {model_info.get('device', 'Unknown')}

Dataset Information:
- Training Examples: {dataset_info.get('total_examples', 'Unknown'):,}
- Average Input Length: {dataset_info.get('avg_input_length', 'Unknown'):.1f} tokens
- Average Target Length: {dataset_info.get('avg_target_length', 'Unknown'):.1f} tokens

Training Configuration:
- Epochs: {training_history.get('num_epochs', 'Unknown')}
- Batch Size: {training_history.get('batch_size', 'Unknown')}
- Learning Rate: {training_history.get('learning_rate', 'Unknown')}
- Total Training Time: {training_history.get('total_time', 'Unknown')}

Training Results:
- Final Loss: {training_history.get('final_loss', 'Unknown'):.4f}
- Best Loss: {training_history.get('best_loss', 'Unknown'):.4f}
- Loss Reduction: {training_history.get('loss_reduction', 'Unknown'):.2f}%

Performance Metrics:
- Training completed successfully: {'Yes' if training_history.get('completed', False) else 'No'}
"""
    
    return report

def validate_model_output(generated_text, min_length=5, max_length=200):
    """Validate generated model output."""
    if not isinstance(generated_text, str):
        return False, "Output is not a string"
    
    if len(generated_text.strip()) < min_length:
        return False, f"Output too short (minimum {min_length} characters)"
    
    if len(generated_text) > max_length:
        return False, f"Output too long (maximum {max_length} characters)"
    
    # Check for repetitive patterns
    words = generated_text.split()
    if len(words) > 1:
        repeated_ratio = len(words) / len(set(words))
        if repeated_ratio > 3:  # Too much repetition
            return False, "Output contains too much repetition"
    
    return True, "Output is valid"
