import torch
import numpy as np
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.tokenize import word_tokenize
import nltk
from rouge_score import rouge_scorer
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import math

class ModelEvaluator:
    def __init__(self):
        """Initialize the model evaluator with necessary tools."""
        try:
            nltk.download('punkt', quiet=True)
        except:
            pass
        
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
        self.smoothing_function = SmoothingFunction().method1
        
    def calculate_bleu_score(self, predictions, references):
        """Calculate BLEU score for predictions against references."""
        bleu_scores = []
        
        for pred, ref in zip(predictions, references):
            # Tokenize
            try:
                pred_tokens = word_tokenize(pred.lower())
                ref_tokens = word_tokenize(ref.lower())
                
                # Calculate BLEU score
                if len(pred_tokens) > 0 and len(ref_tokens) > 0:
                    score = sentence_bleu(
                        [ref_tokens], 
                        pred_tokens,
                        smoothing_function=self.smoothing_function
                    )
                    bleu_scores.append(score)
                else:
                    bleu_scores.append(0.0)
            except:
                bleu_scores.append(0.0)
        
        return np.mean(bleu_scores)
    
    def calculate_rouge_scores(self, predictions, references):
        """Calculate ROUGE scores for predictions against references."""
        rouge1_scores = []
        rouge2_scores = []
        rougeL_scores = []
        
        for pred, ref in zip(predictions, references):
            try:
                scores = self.rouge_scorer.score(ref, pred)
                rouge1_scores.append(scores['rouge1'].f1)
                rouge2_scores.append(scores['rouge2'].f1)
                rougeL_scores.append(scores['rougeL'].f1)
            except:
                rouge1_scores.append(0.0)
                rouge2_scores.append(0.0)
                rougeL_scores.append(0.0)
        
        return {
            'rouge1': np.mean(rouge1_scores),
            'rouge2': np.mean(rouge2_scores),
            'rouge_l': np.mean(rougeL_scores)
        }
    
    def calculate_perplexity(self, model, tokenizer, texts, device=None):
        """Calculate perplexity of the model on given texts."""
        if device is None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        model.eval()
        total_loss = 0
        total_tokens = 0
        
        with torch.no_grad():
            for text in texts:
                try:
                    # Tokenize text
                    encoding = tokenizer(
                        text,
                        return_tensors='pt',
                        truncation=True,
                        max_length=512
                    )
                    
                    input_ids = encoding['input_ids'].to(device)
                    
                    # Calculate loss
                    outputs = model(input_ids, labels=input_ids)
                    loss = outputs.loss
                    
                    # Accumulate loss and token count
                    total_loss += loss.item() * input_ids.size(1)
                    total_tokens += input_ids.size(1)
                    
                except Exception as e:
                    print(f"Error calculating perplexity for text: {e}")
                    continue
        
        if total_tokens > 0:
            avg_loss = total_loss / total_tokens
            perplexity = math.exp(avg_loss)
        else:
            perplexity = float('inf')
        
        return perplexity
    
    def calculate_diversity_metrics(self, predictions):
        """Calculate diversity metrics for generated predictions."""
        if not predictions:
            return {'distinct_1': 0, 'distinct_2': 0, 'entropy': 0}
        
        # Tokenize all predictions
        all_tokens = []
        all_bigrams = []
        
        for pred in predictions:
            try:
                tokens = word_tokenize(pred.lower())
                all_tokens.extend(tokens)
                
                # Create bigrams
                bigrams = [(tokens[i], tokens[i+1]) for i in range(len(tokens)-1)]
                all_bigrams.extend(bigrams)
            except:
                continue
        
        # Calculate distinct-1 (unique unigrams / total unigrams)
        distinct_1 = len(set(all_tokens)) / len(all_tokens) if all_tokens else 0
        
        # Calculate distinct-2 (unique bigrams / total bigrams)
        distinct_2 = len(set(all_bigrams)) / len(all_bigrams) if all_bigrams else 0
        
        # Calculate entropy
        if all_tokens:
            token_freq = {}
            for token in all_tokens:
                token_freq[token] = token_freq.get(token, 0) + 1
            
            total_tokens = len(all_tokens)
            entropy = -sum((freq / total_tokens) * math.log2(freq / total_tokens) 
                          for freq in token_freq.values())
        else:
            entropy = 0
        
        return {
            'distinct_1': distinct_1,
            'distinct_2': distinct_2,
            'entropy': entropy
        }
    
    def calculate_semantic_similarity(self, predictions, references):
        """Calculate semantic similarity between predictions and references."""
        # Simple word overlap-based similarity
        similarities = []
        
        for pred, ref in zip(predictions, references):
            try:
                pred_words = set(word_tokenize(pred.lower()))
                ref_words = set(word_tokenize(ref.lower()))
                
                if len(pred_words) == 0 and len(ref_words) == 0:
                    similarity = 1.0
                elif len(pred_words) == 0 or len(ref_words) == 0:
                    similarity = 0.0
                else:
                    intersection = len(pred_words & ref_words)
                    union = len(pred_words | ref_words)
                    similarity = intersection / union  # Jaccard similarity
                
                similarities.append(similarity)
            except:
                similarities.append(0.0)
        
        return np.mean(similarities)
    
    def evaluate_model(self, predictions, references, model=None, tokenizer=None):
        """Comprehensive model evaluation."""
        results = {}
        
        print("Calculating BLEU score...")
        results['bleu'] = self.calculate_bleu_score(predictions, references)
        
        print("Calculating ROUGE scores...")
        rouge_scores = self.calculate_rouge_scores(predictions, references)
        results.update(rouge_scores)
        
        print("Calculating diversity metrics...")
        diversity_metrics = self.calculate_diversity_metrics(predictions)
        results.update(diversity_metrics)
        
        print("Calculating semantic similarity...")
        results['semantic_similarity'] = self.calculate_semantic_similarity(predictions, references)
        
        if model and tokenizer:
            print("Calculating perplexity...")
            # Use references for perplexity calculation
            results['perplexity'] = self.calculate_perplexity(model, tokenizer, references)
        else:
            # Estimate perplexity based on text length (rough approximation)
            avg_length = np.mean([len(pred.split()) for pred in predictions])
            results['perplexity'] = max(1.0, 50.0 / max(avg_length, 1))
        
        # Calculate overall quality score (weighted combination)
        quality_score = (
            results['bleu'] * 0.3 +
            results['rouge_l'] * 0.3 +
            results['semantic_similarity'] * 0.2 +
            (1.0 / max(results['perplexity'], 1)) * 0.2
        )
        results['quality_score'] = quality_score
        
        return results
    
    def generate_evaluation_report(self, results):
        """Generate a detailed evaluation report."""
        report = f"""
Model Evaluation Report
======================

Automatic Metrics:
- BLEU Score: {results.get('bleu', 0):.4f}
- ROUGE-1: {results.get('rouge1', 0):.4f}
- ROUGE-2: {results.get('rouge2', 0):.4f}
- ROUGE-L: {results.get('rouge_l', 0):.4f}
- Perplexity: {results.get('perplexity', 0):.2f}

Diversity Metrics:
- Distinct-1: {results.get('distinct_1', 0):.4f}
- Distinct-2: {results.get('distinct_2', 0):.4f}
- Entropy: {results.get('entropy', 0):.4f}

Semantic Analysis:
- Semantic Similarity: {results.get('semantic_similarity', 0):.4f}
- Overall Quality Score: {results.get('quality_score', 0):.4f}

Interpretation:
- BLEU Score: Higher is better (0-1 range)
- ROUGE Scores: Higher is better (0-1 range)  
- Perplexity: Lower is better
- Diversity Metrics: Higher indicates more diverse responses
- Quality Score: Overall assessment (0-1 range)
"""
        return report
    
    def compare_models(self, results_list, model_names):
        """Compare multiple models' evaluation results."""
        if len(results_list) != len(model_names):
            raise ValueError("Number of results and model names must match")
        
        comparison = {}
        metrics = ['bleu', 'rouge_l', 'perplexity', 'quality_score']
        
        for metric in metrics:
            comparison[metric] = {}
            for i, name in enumerate(model_names):
                comparison[metric][name] = results_list[i].get(metric, 0)
        
        return comparison
