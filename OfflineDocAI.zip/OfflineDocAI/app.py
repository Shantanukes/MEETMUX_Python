import streamlit as st
import pandas as pd
import numpy as np
import torch
import joblib
import os
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns

from data_processor import DataProcessor
from model_trainer import ModelTrainer
from chat_generator import ChatGenerator
from evaluator import ModelEvaluator
from sample_data_creator import create_sample_data

# Set page config
st.set_page_config(
    page_title="Chat Reply Recommendation System",
    page_icon="💬",
    layout="wide"
)

st.title("💬 Offline Chat Reply Recommendation System")
st.markdown("An AI-powered system that predicts User A's responses based on conversation history")

# Initialize session state
if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
if 'processor' not in st.session_state:
    st.session_state.processor = None
if 'generator' not in st.session_state:
    st.session_state.generator = None
if 'evaluation_results' not in st.session_state:
    st.session_state.evaluation_results = None

# Sidebar for navigation
st.sidebar.title("Navigation")
page = st.sidebar.selectbox(
    "Select Page",
    ["Data Upload & Processing", "Model Training", "Chat Generation", "Model Evaluation", "Export Model"]
)

# Data Upload & Processing Page
if page == "Data Upload & Processing":
    st.header("📁 Data Upload & Processing")
    
    # Option to create sample data or upload real data
    data_option = st.radio(
        "Choose data source:",
        ["Create Sample Data", "Upload CSV Files"]
    )
    
    if data_option == "Create Sample Data":
        st.info("Creating sample conversation data for demonstration")
        if st.button("Generate Sample Data"):
            with st.spinner("Generating sample conversation data..."):
                create_sample_data()
                st.success("Sample data created successfully!")
                st.info("Files created: userA_chats.csv and userB_chats.csv")
    
    else:
        st.subheader("Upload Conversation Files")
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**User A Chat File**")
            userA_file = st.file_uploader(
                "Upload User A conversations (CSV)",
                type=['csv'],
                key="userA"
            )
        
        with col2:
            st.write("**User B Chat File**")
            userB_file = st.file_uploader(
                "Upload User B conversations (CSV)",
                type=['csv'],
                key="userB"
            )
        
        if userA_file and userB_file:
            # Save uploaded files
            with open("userA_chats.csv", "wb") as f:
                f.write(userA_file.read())
            with open("userB_chats.csv", "wb") as f:
                f.write(userB_file.read())
            st.success("Files uploaded successfully!")
    
    # Process data if files exist
    if os.path.exists("userA_chats.csv") and os.path.exists("userB_chats.csv"):
        st.subheader("Data Processing")
        
        if st.button("Process Conversation Data"):
            with st.spinner("Processing conversation data..."):
                processor = DataProcessor()
                processed_data = processor.load_and_process_data(
                    "userA_chats.csv", 
                    "userB_chats.csv"
                )
                st.session_state.processor = processor
                
                st.success(f"Data processed successfully!")
                st.info(f"Total conversation pairs: {len(processed_data)}")
                
                # Display sample data
                st.subheader("Sample Processed Data")
                sample_df = pd.DataFrame(processed_data[:5])
                st.dataframe(sample_df)
                
                # Display data statistics
                st.subheader("Data Statistics")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    avg_input_len = np.mean([len(item['input_text'].split()) for item in processed_data])
                    st.metric("Avg Input Length (words)", f"{avg_input_len:.1f}")
                
                with col2:
                    avg_target_len = np.mean([len(item['target_text'].split()) for item in processed_data])
                    st.metric("Avg Target Length (words)", f"{avg_target_len:.1f}")
                
                with col3:
                    st.metric("Total Pairs", len(processed_data))

# Model Training Page
elif page == "Model Training":
    st.header("🤖 Model Training")
    
    if st.session_state.processor is None:
        st.warning("Please process data first in the 'Data Upload & Processing' page.")
    else:
        st.subheader("Training Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            model_name = st.selectbox(
                "Select Base Model",
                ["gpt2", "distilgpt2", "microsoft/DialoGPT-medium"]
            )
            
            epochs = st.slider("Training Epochs", 1, 10, 3)
            
        with col2:
            learning_rate = st.select_slider(
                "Learning Rate",
                options=[1e-5, 2e-5, 3e-5, 5e-5],
                value=2e-5,
                format_func=lambda x: f"{x:.0e}"
            )
            
            batch_size = st.selectbox("Batch Size", [2, 4, 8], index=1)
        
        if st.button("Start Training"):
            with st.spinner("Training model... This may take several minutes."):
                trainer = ModelTrainer(
                    model_name=model_name,
                    learning_rate=learning_rate,
                    num_epochs=epochs,
                    batch_size=batch_size
                )
                
                # Create progress bar
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                # Train model with progress updates
                model, tokenizer = trainer.train(
                    st.session_state.processor.processed_data,
                    progress_callback=lambda epoch, total: progress_bar.progress((epoch + 1) / total)
                )
                
                st.session_state.model_trained = True
                st.session_state.generator = ChatGenerator(model, tokenizer)
                
                st.success("Model training completed!")
                st.info("You can now generate replies in the 'Chat Generation' page.")

# Chat Generation Page
elif page == "Chat Generation":
    st.header("💬 Chat Generation")
    
    if not st.session_state.model_trained:
        st.warning("Please train the model first in the 'Model Training' page.")
    else:
        st.subheader("Interactive Chat Interface")
        
        # Chat history
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []
        
        # Input for new message
        st.subheader("User B's Message")
        user_b_message = st.text_area(
            "Enter User B's message:",
            height=100,
            placeholder="Type User B's message here..."
        )
        
        # Generation parameters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            max_length = st.slider("Max Reply Length", 20, 200, 100)
        
        with col2:
            temperature = st.slider("Temperature", 0.1, 2.0, 0.8)
        
        with col3:
            top_p = st.slider("Top-p", 0.1, 1.0, 0.9)
        
        if st.button("Generate Reply") and user_b_message.strip():
            with st.spinner("Generating User A's reply..."):
                # Use conversation history as context
                context = "\n".join([f"User B: {msg['user_b']}\nUser A: {msg['user_a']}" 
                                   for msg in st.session_state.chat_history[-3:]])  # Last 3 exchanges
                
                full_context = f"{context}\nUser B: {user_b_message}\nUser A:"
                
                reply = st.session_state.generator.generate_reply(
                    full_context,
                    max_length=max_length,
                    temperature=temperature,
                    top_p=top_p
                )
                
                # Add to chat history
                st.session_state.chat_history.append({
                    'user_b': user_b_message,
                    'user_a': reply,
                    'timestamp': datetime.now().strftime("%H:%M:%S")
                })
        
        # Display chat history
        if st.session_state.chat_history:
            st.subheader("Conversation History")
            
            for i, msg in enumerate(reversed(st.session_state.chat_history[-10:])):  # Show last 10
                with st.container():
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.markdown(f"**User B** ({msg['timestamp']}):")
                        st.markdown(f"💙 {msg['user_b']}")
                    
                    with col2:
                        st.markdown(f"**User A (AI)** ({msg['timestamp']}):")
                        st.markdown(f"🤖 {msg['user_a']}")
                    
                    st.divider()
        
        # Clear chat history
        if st.button("Clear Chat History"):
            st.session_state.chat_history = []
            st.rerun()

# Model Evaluation Page
elif page == "Model Evaluation":
    st.header("📊 Model Evaluation")
    
    if not st.session_state.model_trained:
        st.warning("Please train the model first in the 'Model Training' page.")
    else:
        st.subheader("Evaluation Metrics")
        
        if st.button("Run Evaluation"):
            with st.spinner("Evaluating model performance..."):
                evaluator = ModelEvaluator()
                
                # Get test data
                test_data = st.session_state.processor.processed_data[-100:]  # Last 100 samples for testing
                
                # Generate predictions
                predictions = []
                references = []
                
                progress_bar = st.progress(0)
                
                for i, item in enumerate(test_data):
                    pred = st.session_state.generator.generate_reply(
                        item['input_text'],
                        max_length=50,
                        temperature=0.7
                    )
                    predictions.append(pred)
                    references.append(item['target_text'])
                    progress_bar.progress((i + 1) / len(test_data))
                
                # Calculate metrics
                results = evaluator.evaluate_model(predictions, references)
                st.session_state.evaluation_results = results
                
                # Display results
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("BLEU Score", f"{results['bleu']:.4f}")
                
                with col2:
                    st.metric("ROUGE-L", f"{results['rouge_l']:.4f}")
                
                with col3:
                    st.metric("Perplexity", f"{results['perplexity']:.2f}")
                
                # Show sample predictions
                st.subheader("Sample Predictions")
                
                sample_results = []
                for i in range(min(5, len(predictions))):
                    sample_results.append({
                        'Input': test_data[i]['input_text'][:100] + "..." if len(test_data[i]['input_text']) > 100 else test_data[i]['input_text'],
                        'Expected': references[i],
                        'Predicted': predictions[i]
                    })
                
                sample_df = pd.DataFrame(sample_results)
                st.dataframe(sample_df, use_container_width=True)

# Export Model Page
elif page == "Export Model":
    st.header("💾 Export Model")
    
    if not st.session_state.model_trained:
        st.warning("Please train the model first in the 'Model Training' page.")
    else:
        st.subheader("Model Export Options")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.info("**Export trained model for submission**")
            
            if st.button("Export Model as joblib"):
                with st.spinner("Exporting model..."):
                    # Create export data
                    export_data = {
                        'model': st.session_state.generator.model.state_dict(),
                        'tokenizer': st.session_state.generator.tokenizer,
                        'processor': st.session_state.processor,
                        'evaluation_results': st.session_state.evaluation_results,
                        'export_timestamp': datetime.now().isoformat()
                    }
                    
                    # Save using joblib
                    joblib.dump(export_data, 'Model.joblib')
                    
                    st.success("Model exported successfully as 'Model.joblib'!")
                    st.info("File is ready for submission.")
        
        with col2:
            st.info("**Generate README file**")
            
            if st.button("Generate README.txt"):
                readme_content = f"""
Chat Reply Recommendation System
================================

This system uses a fine-tuned GPT-2 model to predict User A's responses 
based on User B's messages and conversation history.

Model Details:
- Base Model: GPT-2
- Fine-tuned on conversation data
- Export Date: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

Evaluation Results:
{f"- BLEU Score: {st.session_state.evaluation_results['bleu']:.4f}" if st.session_state.evaluation_results else "- Not evaluated"}
{f"- ROUGE-L: {st.session_state.evaluation_results['rouge_l']:.4f}" if st.session_state.evaluation_results else ""}
{f"- Perplexity: {st.session_state.evaluation_results['perplexity']:.2f}" if st.session_state.evaluation_results else ""}

Files:
- Model.joblib: Complete trained model and components
- README.txt: This file

Usage:
Load the model using joblib.load('Model.joblib') and use the included
generator for reply prediction.
"""
                
                with open('ReadMe.txt', 'w') as f:
                    f.write(readme_content)
                
                st.success("README.txt generated successfully!")
                st.text_area("README Content:", readme_content, height=300)

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("**System Status**")
if st.session_state.model_trained:
    st.sidebar.success("✅ Model Ready")
else:
    st.sidebar.warning("⏳ Model Not Trained")

if st.session_state.processor:
    st.sidebar.success("✅ Data Processed")
else:
    st.sidebar.warning("⏳ Data Not Processed")
