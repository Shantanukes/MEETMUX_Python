import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

def create_sample_data():
    """Create sample conversation data for testing the system."""
    
    # Sample conversation topics and responses
    conversation_pairs = [
        # Greeting exchanges
        ("Hi there! How are you today?", "Hello! I'm doing great, thanks for asking. How about you?"),
        ("Good morning! Ready for the day?", "Good morning! Yes, I'm excited to get started."),
        ("Hey, what's up?", "Not much, just relaxing. What about you?"),
        
        # Work/Study related
        ("How was your meeting today?", "It went really well! We made good progress on the project."),
        ("Are you working on anything interesting?", "Yes, I'm learning about machine learning. It's fascinating!"),
        ("Did you finish your assignment?", "Just submitted it! I'm glad it's done."),
        ("What are your plans for the weekend?", "I'm thinking of going hiking if the weather is nice."),
        
        # Hobbies and interests
        ("Have you watched any good movies lately?", "I just saw a great sci-fi movie. The special effects were amazing!"),
        ("Do you like to cook?", "I love cooking! I tried making pasta from scratch yesterday."),
        ("What kind of music do you listen to?", "I enjoy a mix of everything, but lately I've been into jazz."),
        ("Are you into sports?", "I enjoy playing tennis and watching basketball."),
        
        # Technology discussions
        ("What do you think about AI?", "I think it's incredibly powerful and will change many industries."),
        ("Have you tried the new app?", "Yes, it's really user-friendly and has great features."),
        ("Do you prefer iOS or Android?", "I've been using Android for years and really like the customization options."),
        
        # Food and restaurants
        ("Want to grab lunch together?", "That sounds great! How about that new Italian place?"),
        ("Have you been to that new restaurant?", "Yes, the food was delicious but it was quite crowded."),
        ("What's your favorite cuisine?", "I love Thai food - the flavors are so complex and delicious."),
        
        # Travel and places
        ("Where would you like to travel next?", "I'd love to visit Japan - the culture and food seem amazing."),
        ("How was your vacation?", "It was wonderful! The beaches were beautiful and the weather was perfect."),
        ("Do you prefer mountains or beaches?", "I love both, but there's something peaceful about mountains."),
        
        # Daily life
        ("How was your commute today?", "Pretty smooth actually, no major traffic jams."),
        ("What time do you usually wake up?", "I'm an early bird - usually around 6:30 AM."),
        ("Do you have any pets?", "Yes, I have a golden retriever named Max. He's adorable!"),
        
        # Weather conversations
        ("Nice weather today, isn't it?", "Absolutely! Perfect for spending time outdoors."),
        ("It's been raining a lot lately.", "Yes, but at least it's good for the plants and gardens."),
        ("Are you ready for winter?", "I'm looking forward to the cozy weather and hot chocolate."),
        
        # Learning and books
        ("What are you reading these days?", "I'm reading a fascinating book about neuroscience."),
        ("Have you learned anything new recently?", "I've been learning Spanish through an online course."),
        ("Do you prefer fiction or non-fiction?", "I enjoy both, but I've been reading more non-fiction lately."),
        
        # Health and fitness
        ("Do you exercise regularly?", "I try to go to the gym three times a week."),
        ("How do you stay healthy?", "I focus on eating well and getting enough sleep."),
        ("Have you tried yoga?", "Yes, it's great for both physical and mental well-being."),
        
        # Future plans
        ("What are your goals for this year?", "I want to learn a new programming language and travel more."),
        ("Any exciting plans coming up?", "I'm planning a camping trip with some friends next month."),
        ("Where do you see yourself in 5 years?", "Hopefully in a career that I'm passionate about and maybe living abroad."),
        
        # Problem solving
        ("I'm having trouble with this code.", "Have you tried debugging it step by step? Sometimes that helps me find the issue."),
        ("My laptop is running slowly.", "Try clearing some disk space and closing unnecessary programs."),
        ("I can't decide what to wear.", "Check the weather forecast and go with something comfortable."),
        
        # Social activities
        ("Want to hang out this weekend?", "Sure! What did you have in mind?"),
        ("Are you going to the party tonight?", "I'm planning to! It should be fun."),
        ("Do you want to join our book club?", "That sounds interesting! What are you reading currently?"),
        
        # Opinions and preferences
        ("What's your favorite season?", "I love autumn - the colors are beautiful and the weather is perfect."),
        ("Do you prefer coffee or tea?", "I'm definitely a coffee person, especially in the morning."),
        ("What's your ideal vacation?", "Somewhere peaceful with beautiful nature, maybe a cabin in the mountains.")
    ]
    
    # Generate User A data
    userA_data = []
    userB_data = []
    
    # Create conversation history with timestamps
    base_time = datetime.now() - timedelta(days=30)
    
    for i, (userB_msg, userA_msg) in enumerate(conversation_pairs):
        # Add some variations to make conversations more realistic
        variations_b = [
            userB_msg,
            userB_msg + " 😊",
            userB_msg.replace("?", "?? 🤔"),
            "Hey, " + userB_msg.lower()
        ]
        
        variations_a = [
            userA_msg,
            userA_msg + " 😄",
            userA_msg + " What do you think?",
            "Well, " + userA_msg.lower()
        ]
        
        # Use random variations
        final_b = random.choice(variations_b)
        final_a = random.choice(variations_a)
        
        # Generate timestamps (simulate conversation over time)
        conversation_time = base_time + timedelta(
            days=i // 3,  # New day every 3 messages
            hours=random.randint(9, 21),  # Between 9 AM and 9 PM
            minutes=random.randint(0, 59)
        )
        
        userB_data.append({
            'timestamp': conversation_time.strftime('%Y-%m-%d %H:%M:%S'),
            'message': final_b,
            'message_id': f"B_{i+1:03d}",
            'conversation_id': f"conv_{(i//5)+1:02d}"  # Group every 5 messages
        })
        
        # User A responds a few minutes later
        response_time = conversation_time + timedelta(minutes=random.randint(1, 15))
        
        userA_data.append({
            'timestamp': response_time.strftime('%Y-%m-%d %H:%M:%S'),
            'message': final_a,
            'message_id': f"A_{i+1:03d}",
            'conversation_id': f"conv_{(i//5)+1:02d}"
        })
    
    # Add some additional random messages to increase dataset size
    additional_userB = [
        "How's everything going?",
        "What's new with you?",
        "Hope you're having a good day!",
        "Any plans for later?",
        "What's on your mind?",
        "How was your day?",
        "Anything interesting happening?",
        "What are you up to?",
        "How's work treating you?",
        "What's the latest?"
    ]
    
    additional_userA = [
        "Things are going well, thanks!",
        "Not much, just the usual routine.",
        "Thank you! Same to you.",
        "Nothing concrete yet, maybe just relax.",
        "Just thinking about weekend plans.",
        "It was productive, thanks for asking!",
        "A few exciting things in the works.",
        "Just catching up on some reading.",
        "It's been busy but rewarding.",
        "Just finished an interesting project."
    ]
    
    # Add additional conversations
    for i, (b_msg, a_msg) in enumerate(zip(additional_userB, additional_userA)):
        conversation_time = base_time + timedelta(
            days=len(conversation_pairs) + i,
            hours=random.randint(9, 21),
            minutes=random.randint(0, 59)
        )
        
        userB_data.append({
            'timestamp': conversation_time.strftime('%Y-%m-%d %H:%M:%S'),
            'message': b_msg,
            'message_id': f"B_{len(conversation_pairs)+i+1:03d}",
            'conversation_id': f"conv_{((len(conversation_pairs)+i)//5)+1:02d}"
        })
        
        response_time = conversation_time + timedelta(minutes=random.randint(1, 15))
        
        userA_data.append({
            'timestamp': response_time.strftime('%Y-%m-%d %H:%M:%S'),
            'message': a_msg,
            'message_id': f"A_{len(conversation_pairs)+i+1:03d}",
            'conversation_id': f"conv_{((len(conversation_pairs)+i)//5)+1:02d}"
        })
    
    # Create DataFrames
    userA_df = pd.DataFrame(userA_data)
    userB_df = pd.DataFrame(userB_data)
    
    # Sort by timestamp to maintain chronological order
    userA_df = userA_df.sort_values('timestamp').reset_index(drop=True)
    userB_df = userB_df.sort_values('timestamp').reset_index(drop=True)
    
    # Save to CSV files
    userA_df.to_csv('userA_chats.csv', index=False)
    userB_df.to_csv('userB_chats.csv', index=False)
    
    print(f"Created sample data:")
    print(f"- User A: {len(userA_df)} messages")
    print(f"- User B: {len(userB_df)} messages")
    print(f"- Time range: {userA_df['timestamp'].min()} to {userA_df['timestamp'].max()}")
    
    return userA_df, userB_df

if __name__ == "__main__":
    create_sample_data()
